// backend/server.js
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, Date.now() + '_' + file.originalname),
});
const upload = multer({ storage });

const dbPath = path.join(__dirname, 'bigupmind.sqlite');
const db = new Database(dbPath);

// Init tables
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT,
  email TEXT UNIQUE,
  password TEXT,
  phone TEXT,
  tier TEXT,
  activated INTEGER DEFAULT 0,
  balance INTEGER DEFAULT 0,
  is_admin INTEGER DEFAULT 0,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS submissions (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  text TEXT,
  image_path TEXT,
  created_at TEXT,
  views INTEGER DEFAULT 0,
  earnings INTEGER DEFAULT 0,
  status TEXT DEFAULT 'Pending'
);

CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY,
  title TEXT,
  message TEXT,
  created_at TEXT
);
`);

const TIERS = { MEGA: { fee: 1500, perView: 50 }, BIGUP: { fee: 1000, perView: 40 }, JUNIOR: { fee: 500, perView: 30 } };

const uuid = () => 'id_' + Math.random().toString(36).slice(2,9);

const findUserByEmail = db.prepare('SELECT * FROM users WHERE email = ?');
const insertUser = db.prepare('INSERT INTO users (id,name,email,password,phone,tier,activated,balance,is_admin,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
const getUserById = db.prepare('SELECT * FROM users WHERE id = ?');

app.post('/api/register', (req, res) => {
  const { name, email, password, phone, tier } = req.body;
  if (!name || !email || !password || !phone) return res.status(400).json({ error: 'Missing fields' });
  const exists = findUserByEmail.get(email);
  if (exists) return res.status(400).json({ error: 'Email exists' });
  const id = uuid();
  const is_admin = email === 'bigupmind@gmail.com' ? 1 : 0;
  insertUser.run(id, name, email, password, phone, tier, 0, 0, is_admin, new Date().toISOString());
  const user = getUserById.get(id);
  res.json({ user });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const u = findUserByEmail.get(email);
  if (!u || u.password !== password) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ user: u });
});

app.get('/api/users', (req, res) => {
  const users = db.prepare('SELECT id,name,email,phone,tier,activated,balance,is_admin,created_at FROM users').all();
  res.json({ users });
});

app.post('/api/activate', (req, res) => {
  const { userId } = req.body;
  const user = getUserById.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  db.prepare('UPDATE users SET activated = 1 WHERE id = ?').run(userId);
  res.json({ ok: true });
});

app.post('/api/submit', upload.single('image'), (req, res) => {
  const { userId, text } = req.body;
  const user = getUserById.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (!user.activated) return res.status(403).json({ error: 'Activate account first' });
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });
  const id = uuid();
  db.prepare('INSERT INTO submissions (id,user_id,text,image_path,created_at,views,earnings,status) VALUES (?,?,?,?,?,?,?,?)')
    .run(id, userId, text, req.file.filename, new Date().toISOString(), 0, 0, 'Pending');
  res.json({ ok: true, id });
});

app.get('/api/submissions', (req, res) => {
  const subs = db.prepare('SELECT s.*, u.name as user_name, u.email as user_email FROM submissions s LEFT JOIN users u ON s.user_id = u.id ORDER BY created_at DESC').all();
  res.json({ submissions: subs });
});

app.post('/api/admin/approve', (req, res) => {
  const { submissionId } = req.body;
  const sub = db.prepare('SELECT * FROM submissions WHERE id = ?').get(submissionId);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });
  if (sub.status === 'Approved') return res.json({ ok: true, message: 'Already approved' });
  db.prepare('UPDATE submissions SET status = ? WHERE id = ?').run('Approved', submissionId);
  res.json({ ok: true });
});

app.post('/api/simulate_view', (req, res) => {
  const { submissionId } = req.body;
  const sub = db.prepare('SELECT * FROM submissions WHERE id = ?').get(submissionId);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });
  const user = getUserById.get(sub.user_id);
  const rate = TIERS[user.tier].perView;
  const newViews = sub.views + 1;
  const newEarnings = sub.earnings + rate;
  db.prepare('UPDATE submissions SET views = ?, earnings = ? WHERE id = ?').run(newViews, newEarnings, submissionId);
  db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(user.balance + rate, user.id);
  res.json({ ok: true, views: newViews, earnings: newEarnings });
});

app.get('/uploads/:file', (req, res) => {
  const p = path.join(UPLOAD_DIR, req.params.file);
  if (!fs.existsSync(p)) return res.status(404).send('Not found');
  res.sendFile(p);
});

app.post('/api/announce', (req, res) => {
  const { title, message } = req.body;
  const id = uuid();
  db.prepare('INSERT INTO announcements (id,title,message,created_at) VALUES (?,?,?,?)').run(id, title, message, new Date().toISOString());
  res.json({ ok: true });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Server running on port', PORT));
