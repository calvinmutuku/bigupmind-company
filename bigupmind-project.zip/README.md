
BigUpMind Open Company - Deployable project
=========================================

Project contains:
- frontend/ (Vite + React)
- backend/ (Node + Express + SQLite)

Admin credentials:
- Email: bigupmind@gmail.com
- Use the registration form to register with that email to create admin (password you provided).

Paybill for activation:
- Paybill: 247247
- Account: 0340186565011

How to run locally:
1. Backend:
   cd backend
   npm install
   node server.js
   (server on http://localhost:4000)

2. Frontend:
   cd frontend
   npm install
   npm run dev
   (vite dev server; set VITE_API_URL if backend on other host)

Deployment:
- Push to GitHub and use Render or Railway for backend; deploy frontend to Vercel and point API_URL to backend URL.

