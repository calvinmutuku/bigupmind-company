import React, { useEffect, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

function uid(prefix="id"){ return prefix + "_" + Math.random().toString(36).slice(2,9); }

export default function App(){
  const [page,setPage]=useState("home");
  const [user,setUser]=useState(null);
  const [loginForm,setLoginForm]=useState({email:"",password:""});
  const [reg,setReg]=useState({name:"",email:"",password:"",phone:"",tier:"JUNIOR"});
  const [statusText,setStatusText]=useState("");
  const [file,setFile]=useState(null);
  const [submissions,setSubmissions]=useState([]);
  const [users,setUsers]=useState([]);
  const [announcements,setAnnouncements]=useState([]);
  const [adminMode,setAdminMode]=useState(false);

  useEffect(()=>{ fetchSubs(); fetchUsers(); fetchAnnouncements(); const s=localStorage.getItem("bigup_user"); if(s) setUser(JSON.parse(s)); },[]);

  async function fetchSubs(){
    try{
      const r=await fetch(API_URL+"/api/submissions");
      const j=await r.json();
      setSubmissions(j.submissions||[]);
    }catch(e){ console.error(e); }
  }
  async function fetchUsers(){
    try{ const r=await fetch(API_URL+"/api/users"); const j=await r.json(); setUsers(j.users||[]); }catch(e){}
  }
  async function fetchAnnouncements(){
    try{ const r=await fetch(API_URL+"/api/announcements"); const j=await r.json(); setAnnouncements(j.announcements||[]); }catch(e){}
  }

  async function register(){
    if(!reg.name||!reg.email||!reg.password||!reg.phone) return alert("Fill all fields");
    const r=await fetch(API_URL+"/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(reg)});
    const j=await r.json();
    if(r.ok){ setUser(j.user); localStorage.setItem("bigup_user", JSON.stringify(j.user)); setPage("dashboard"); fetchUsers(); }
    else alert(j.error||"Error");
  }

  async function login(){
    const r=await fetch(API_URL+"/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(loginForm)});
    const j=await r.json();
    if(r.ok){ setUser(j.user); localStorage.setItem("bigup_user", JSON.stringify(j.user)); setPage(j.user.is_admin? "admin":"dashboard"); }
    else alert(j.error||"Login failed");
  }

  function logout(){ setUser(null); localStorage.removeItem("bigup_user"); setPage("home"); }

  async function activate(){
    if(!user) return alert("Login required");
    const r=await fetch(API_URL+"/api/activate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:user.id})});
    const j=await r.json();
    if(r.ok){ alert("Activated"); const updated = {...user, activated:1}; setUser(updated); localStorage.setItem("bigup_user", JSON.stringify(updated)); fetchUsers(); }
    else alert(j.error||"Error");
  }

  function handleFile(e){ setFile(e.target.files[0]); }

  async function submitStatus(){
    if(!user) return alert("Login required");
    if(!user.activated) return alert("Activate account first");
    if(!file||!statusText) return alert("Provide screenshot and text");
    const form = new FormData();
    form.append("userId", user.id);
    form.append("text", statusText);
    form.append("image", file);
    const r = await fetch(API_URL+"/api/submit", { method:"POST", body: form });
    const j = await r.json();
    if(r.ok){ alert("Submitted"); setStatusText(""); setFile(null); fetchSubs(); }
    else alert(j.error||"Error");
  }

  async function simulateView(subId){
    await fetch(API_URL+"/api/simulate_view", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({submissionId:subId})});
    fetchSubs(); fetchUsers();
  }

  async function adminApprove(subId){
    await fetch(API_URL+"/api/admin/approve", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({submissionId:subId})});
    fetchSubs();
  }

  async function postAnnouncement(title,message){
    await fetch(API_URL+"/api/announce", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({title,message})});
    fetchAnnouncements();
  }

  return (
    <div>
      <div className="header">
        <div><strong>BigUpMind Open Company</strong></div>
        <div>
          <button className="btn" onClick={()=>setPage("home")}>Home</button>
          <button className="btn" onClick={()=>setPage("about")}>About</button>
          <button className="btn" onClick={()=>setPage("terms")}>Terms</button>
          {user ? <><button className="btn" onClick={()=>setPage(user.is_admin? "admin":"dashboard")}>Dashboard</button><button className="btn" onClick={logout}>Logout</button></> : <><button className="btn" onClick={()=>setPage("login")}>Login</button><button className="btn btn-primary" onClick={()=>setPage("register")}>Register</button></>}
        </div>
      </div>

      <div className="container">
        {page==="home" && (
          <>
            <h2>Turn WhatsApp statuses into income</h2>
            <p>Paybill 247247 | Account: 0340186565011. Motto: Empowering Youths through Digital Innovation and Smart Marketing.</p>
            <div>
              <h4>Announcements</h4>
              {announcements.map(a=> <div key={a.id} className="card"><strong>{a.title}</strong><div>{a.message}</div></div>)}
            </div>
            <h4>Recent submissions</h4>
            {submissions.slice(0,6).map(s=> <div key={s.id} className="card"><img src={`${API_URL}/uploads/${s.image_path}`} style={{width:120}} alt="s"/><div>{s.text}</div><div>By: {s.user_name}</div><div>Status: {s.status}</div></div>)}
          </>
        )}

        {page==="about" && (
          <div>
            <h3>About BigUpMind</h3>
            <p>BigUpMind Open Company is headquartered in South Africa and partnered with Kenya to reduce youth unemployment by paying clients to post promotional WhatsApp statuses.</p>
          </div>
        )}

        {page==="terms" && (
          <div>
            <h3>Terms & Conditions</h3>
            <ul>
              <li>Activation required. Paybill 247247 Account: 0340186565011.</li>
              <li>Provide correct phone number for payouts.</li>
              <li>Fraud leads to suspension.</li>
            </ul>
          </div>
        )}

        {page==="register" && (
          <div>
            <h3>Register</h3>
            <input className="input" placeholder="Full name" value={reg.name} onChange={e=>setReg({...reg,name:e.target.value})}/>
            <input className="input" placeholder="Email" value={reg.email} onChange={e=>setReg({...reg,email:e.target.value})}/>
            <input className="input" placeholder="Phone for payouts" value={reg.phone} onChange={e=>setReg({...reg,phone:e.target.value})}/>
            <input className="input" placeholder="Password" type="password" value={reg.password} onChange={e=>setReg({...reg,password:e.target.value})}/>
            <select className="input" value={reg.tier} onChange={e=>setReg({...reg,tier:e.target.value})}>
              <option value="MEGA">Mega</option>
              <option value="BIGUP">BigUp</option>
              <option value="JUNIOR">Junior</option>
            </select>
            <button className="btn btn-primary" onClick={register}>Create account</button>
          </div>
        )}

        {page==="login" && (
          <div>
            <h3>Login</h3>
            <input className="input" placeholder="Email" value={loginForm.email} onChange={e=>setLoginForm({...loginForm,email:e.target.value})}/>
            <input className="input" placeholder="Password" type="password" value={loginForm.password} onChange={e=>setLoginForm({...loginForm,password:e.target.value})}/>
            <button className="btn btn-primary" onClick={login}>Login</button>
          </div>
        )}

        {page==="dashboard" && user && (
          <div>
            <h3>Dashboard — {user.name}</h3>
            <p>Tier: {user.tier} | Activated: {user.activated ? "Yes":"No"} | Balance: KES {user.balance}</p>
            {!user.activated && <div className="card"><p>Activation fee: see Paybill 247247 Account 0340186565011</p><button className="btn" onClick={activate}>Confirm Activation (I paid)</button></div>}
            <h4>Submit WhatsApp screenshot</h4>
            <textarea className="input" placeholder="Describe status" value={statusText} onChange={e=>setStatusText(e.target.value)} />
            <input type="file" onChange={handleFile} />
            <button className="btn btn-primary" onClick={submitStatus}>Submit</button>

            <h4>Your Submissions</h4>
            {submissions.filter(s=>s.user_id===user.id).map(s=> <div key={s.id} className="card"><img src={`${API_URL}/uploads/${s.image_path}`} style={{width:120}} alt="s"/><div>{s.text}</div><div>Views: {s.views} Earnings: KES {s.earnings}</div></div>)}
          </div>
        )}

        {page==="admin" && user && user.is_admin && (
          <div>
            <h3>Admin Panel — {user.name}</h3>
            <h4>Submissions</h4>
            {submissions.map(s=> <div key={s.id} className="card"><img src={`${API_URL}/uploads/${s.image_path}`} style={{width:120}} alt="s"/><div>{s.text}</div><div>By: {s.user_name} {s.user_email}</div><div>Status: {s.status}</div><button className="btn" onClick={()=>adminApprove(s.id)}>Approve</button><button className="btn" onClick={()=>simulateView(s.id)}>Simulate view</button></div>)}
            <h4>Users</h4>
            {users.map(u=> <div key={u.id} className="card"><div>{u.name} | {u.email} | {u.phone} | Tier: {u.tier} | Activated: {u.activated} | Balance: KES {u.balance}</div></div>)}
            <h4>Post Announcement</h4>
            <Announcer onPost={(t,m)=>postAnnouncement(t,m)} />
          </div>
        )}
      </div>
    </div>
  );
}

function Announcer({onPost}){
  const [title,setTitle]=useState(""); const [msg,setMsg]=useState("");
  return (<div><input className="input" placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)}/><textarea className="input" placeholder="Message" value={msg} onChange={e=>setMsg(e.target.value)}/><button className="btn btn-primary" onClick={()=>{ onPost(title,msg); setTitle(""); setMsg(""); }}>Post</button></div>);
}
